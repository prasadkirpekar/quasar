﻿
Partial Class contents_templates_bs_bs
    Inherits System.Web.UI.MasterPage
End Class


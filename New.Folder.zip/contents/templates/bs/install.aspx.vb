﻿
Partial Class contents_templates_bs_install
    Inherits System.Web.UI.Page
    Dim x As Template = New Template()
    Protected Sub install_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles install.Click
        Dim c As ArrayList = New ArrayList()
        Dim d As ArrayList = New ArrayList()
        Dim k As ArrayList = New ArrayList()
        c.Add("id")
        c.Add("value")
        d.Add("int")
        d.Add("varchar(1000)")
        k.Add("not null unique")
        k.Add("not null")
        If x.add_table("bs", c, d, k) Then
            x.register_template("bs")
            Dim init As ArrayList = New ArrayList()
            init.Add(1)
            init.Add("Goto the admin panel to add info here")
            x.insert_to_table("bs", init)

            Response.Redirect("~/contents/templates/bs/options.aspx")
        End If
    End Sub
End Class

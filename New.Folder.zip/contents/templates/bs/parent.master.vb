﻿
Partial Class contents_templates_bs_parent
    Inherits System.Web.UI.MasterPage
End Class


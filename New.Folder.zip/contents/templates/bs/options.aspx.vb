﻿
Partial Class contents_templates_bs_options
    Inherits System.Web.UI.Page

End Class

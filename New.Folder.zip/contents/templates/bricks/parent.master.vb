﻿
Partial Class contents_templates_bricks_parent
    Inherits System.Web.UI.MasterPage

    Protected Sub search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles search.Click
        If Not squery.Text = "" Then
            Response.Redirect("~/search/" + squery.Text.Replace(" ", "-"))
        Else
            squery.Text = "Enter search query"
        End If
    End Sub
End Class


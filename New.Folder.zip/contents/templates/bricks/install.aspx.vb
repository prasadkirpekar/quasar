﻿
Partial Class contents_templates_bricks_install
    Inherits System.Web.UI.Page
    Dim x As Template = New Template()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.Write("True")
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If x.register_template("bricks") Then
            Button1.Text = "Done!"
            Button1.CssClass = "btn btn-success btn-lg form-center"
            Button1.Enabled = False
        Else
            Button1.Text = "Failed! Retry"
            Button1.CssClass = "btn btn-danger btn-lg form-center"
        End If
    End Sub
End Class

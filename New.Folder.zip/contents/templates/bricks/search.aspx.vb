﻿
Partial Class contents_templates_bricks_search
    Inherits System.Web.UI.Page

End Class

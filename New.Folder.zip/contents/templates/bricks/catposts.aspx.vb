﻿
Partial Class contents_templates_bricks_catposts
    Inherits System.Web.UI.Page

End Class

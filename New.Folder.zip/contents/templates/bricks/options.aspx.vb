﻿
Partial Class contents_templates_bricks_options
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim f As FileOperations = New FileOperations()
        Label1.Text = f._upload(FileUpload1, Server.MapPath("~/"))
    End Sub
End Class

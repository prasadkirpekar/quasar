﻿Imports System.Web.Routing
Partial Class contents_templates_bricks_bricks
    Inherits System.Web.UI.MasterPage
    Dim x As DatabaseQueries = New DatabaseQueries()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        load_data()
    End Sub
    Sub load_data()
        If Not x.Get_option(17) = "None" Then
            home_page_title.Text = x.Get_option(17)
            homepage_text.Text = x.GET_BY_ID(x.GET_ID("contents", "title", x.Get_option(17)), "ctext", "contents")
            homepge.Visible = True
        Else
            post_list.Visible = True
        End If
    End Sub
End Class


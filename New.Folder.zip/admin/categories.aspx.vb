﻿
Partial Class Categories
    Inherits System.Web.UI.Page
    Dim x As DatabaseQueries = New DatabaseQueries()
    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Response.Redirect("../admin/categories.aspx?mode=new")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim mode As String = Request.QueryString("mode")
        If mode = "new" Then
            new_category.Visible = True
        ElseIf mode = "all" Then
            all_categories.Visible = True
            load_categories()
        ElseIf mode = "edit" Then
            If Not IsPostBack Then
                edit_category(Request.QueryString("id"))
            End If
            new_category.Visible = True
            add_cat.Text = "Upadate category"
        ElseIf mode = "delete" Then
            x._delete("categories", Request.QueryString("id"))
            Response.Redirect("~/admin/categories.aspx")
        Else
            all_categories.Visible = True
            End If
    End Sub

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete

    End Sub

    Protected Sub add_cat_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles add_cat.Click
        If Request.QueryString("mode") = "edit" Then
            If x.update_category(Request.QueryString("id"), cat_title.Text, desc.Text) Then
                alert.Text = "done"
            Else
                alert.Text = "failed"
            End If
        Else
            Dim cat_detail As ArrayList = New ArrayList()
            cat_detail.Add(cat_title.Text)
            cat_detail.Add(desc.Text)
            cat_detail.Add(0)
            If x.Put_data("categories", cat_detail) Then
                alert.Text = "done"
            Else
                alert.Text = "failed"
            End If
        End If
    End Sub
    Sub load_categories()
        Dim cat_id As ArrayList = x.Get_categories("id")
        Dim cat_list As ArrayList = x.Get_categories("title")
        Dim cat_desc As ArrayList = x.Get_categories("description")
        Dim p_count As ArrayList = x.Get_categories("post_count")
        For i As Integer = cat_id.Count - 1 To 0 Step -1
            t.Text += "<tr><td><input id=c" + cat_id(i).ToString() + " type='checkbox'/></td><td><a href='categories.aspx?mode=edit&id=" + cat_id(i).ToString() + "'>" + cat_list(i).ToString() + "</a></td><td>" + cat_desc(i).ToString() + "</td><td>" + p_count(i).ToString() + "</td><td><a href='categories.aspx?mode=delete&id=" + cat_id(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"
        Next
    End Sub

    Sub edit_category(ByVal id As Integer)
        cat_title.Text = x.GET_BY_ID(id, "title", "categories")
        desc.Text = x.GET_BY_ID(id, "description", "categories")
    End Sub

    Protected Sub all_redirect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles all_redirect.Click
        Response.Redirect("../admin/categories.aspx?mode=all")
    End Sub
End Class

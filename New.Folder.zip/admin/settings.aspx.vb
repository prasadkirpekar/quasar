﻿Imports DatabaseQueries
Partial Class admin_Settings
    Inherits System.Web.UI.Page
    Dim x As DatabaseQueries = New DatabaseQueries()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim type As String = Request.QueryString("type")
        If type = "notification" Then
            notification.Visible = True
        ElseIf type = "seo" Then
            seo.Visible = True
        ElseIf type = "template" Then
            template.Visible = True
        ElseIf type = "general" Then
            general.Visible = True
        ElseIf type = "sharing" Then
            sharing.Visible = True
        Else
            general.Visible = True
        End If
        If Not IsPostBack Then
            load_settings(type)
        End If

    End Sub

    Protected Sub save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save.Click
        
        Dim comm_status As Integer
        Dim _role As Integer
        Dim reg As String
        If comment_publist_option.SelectedValue = "Instantly" Then
            comm_status = 1
        Else
            comm_status = 0
        End If
        If role.SelectedValue = "Administrator" Then
            _role = 1
        ElseIf role.SelectedValue = "Contributor" Then
            _role = 2
        Else
            _role = 3
        End If
        


        If x.Add_option(1, site_title.Text) And x.Add_option(2, site_desc.Text) And x.Add_option(3, site_url.Text) And x.Add_option(4, comm_status.ToString()) And x.Add_option(5, allow_register.Checked) And x.Add_option(6, _role.ToString()) Then
            alert.Text = "Settings saved"
            alert.CssClass = "alert alert-success"
            alert.Visible = True
            load_settings("general")
        Else
            alert.Text = "Failed! unable to connect database"
            alert.CssClass = "alert alert-danger"
            alert.Visible = True
        End If

    End Sub
    Sub load_settings(ByVal type As String)
        Dim pages As ArrayList = x.Get_Content(2, "title")
        Dim status As ArrayList = x.Get_Content(2, "status")
        Dim index As Integer

        If type = "general" Then
            site_title.Text = x.Get_option(1)
            site_desc.Text = x.Get_option(2)
            site_url.Text = x.Get_option(3)
            allow_register.Checked = x.Get_option(5)
            
        ElseIf type = "template" Then
            
            Dim home As String = x.Get_option(17)
            If home = "None" Then
                post_pages.Enabled = False
                For i As Integer = pages.Count - 1 To 0 Step -1
                    If status(i).ToString() = "1" Then
                        home_pages.Items.Add(pages(i))
                        post_pages.Items.Add(pages(i))
                    End If
                Next
                home_pages.SelectedIndex = 0
            Else


                For i As Integer = pages.Count - 1 To 0 Step -1
                    If pages(i).ToString() = home Then
                        index = pages.Count - i
                    End If
                    If status(i).ToString() = "1" Then
                        home_pages.Items.Add(pages(i))
                        post_pages.Items.Add(pages(i))
                    End If
                Next

                home_pages.SelectedIndex = index
            End If
        ElseIf type = "seo" Then
            home_meta.Text = x.Get_option(11)
            is_custom_seo.Checked = x.Get_option(12)
            Dim fzf_page As String = x.Get_option(13)
            For i As Integer = pages.Count - 1 To 0 Step -1
                If pages(i).ToString() = fzf_page Then
                    index = pages.Count - i
                End If
                fzf.Items.Add(pages(i))

            Next

            fzf.SelectedIndex = index
            gmeta.Text = x.Get_option(14)
            bmeta.Text = x.Get_option(15)
        ElseIf type = "notification" Then
            isemail.Checked = x.Get_option(21)
            isfeedback.Checked = x.Get_option(22)
            isdropdown.Checked = x.Get_option(23)
            email_template.Text = x.Get_option(24)
        ElseIf type = "sharing" Then
            fb_share.Checked = x.Get_option(31)
            tw_share.Checked = x.Get_option(32)
            g_share.Checked = x.Get_option(33)
            share_text.Text = x.Get_option(34)
        End If
    End Sub

    Protected Sub save_temp_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save_temp.Click
        alert.Visible = True
        If home_pages.SelectedValue = post_pages.SelectedValue Then
            alert.Text = "Home page and post page can't be same"
            Exit Sub
        End If
        If x.Add_option(17, home_pages.SelectedValue.ToString()) And x.Add_option(18, post_pages.SelectedValue) Then
            alert.Text = "done"
        Else
            alert.Text = "failed"
        End If
    End Sub

    Protected Sub save_seo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save_seo.Click
        If x.Add_option(11, home_meta.Text) And x.Add_option(12, is_custom_seo.Checked) And x.Add_option(13, fzf.SelectedValue) And x.Add_option(14, gmeta.Text) And x.Add_option(15, bmeta.Text) Then
            alert.Text = "done"
        Else
            alert.Text = "failed"
        End If
        alert.Visible = True
    End Sub

    Protected Sub save_noti_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save_noti.Click
        If x.Add_option(21, isemail.Checked) And x.Add_option(22, isfeedback.Checked) And x.Add_option(23, isdropdown.Checked) And x.Add_option(24, email_template.Text) Then
            alert.Text = "done"
        Else
            alert.Text = "failed"
        End If
        alert.Visible = True
    End Sub

    Protected Sub save_share_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save_share.Click
        If x.Add_option(31, fb_share.Checked) And x.Add_option(32, tw_share.Checked) And x.Add_option(33, g_share.Checked) And x.Add_option(34, share_text.Text) Then
            alert.Text = "done"
        Else
            alert.Text = "failed"
        End If
        alert.Visible = True
    End Sub
End Class

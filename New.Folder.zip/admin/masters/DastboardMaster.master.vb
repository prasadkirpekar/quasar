﻿Imports security
Imports Notifications
Partial Class admin_masters_DastboardMaster
    Inherits System.Web.UI.MasterPage
    Dim x1 As DatabaseQueries = New DatabaseQueries
    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If x1.init() = False Then
            Response.Redirect("~/installer.aspx")
        End If
        Dim username As String = Session("name")
        If username = "" Then

            Response.Redirect("~/login.aspx?action=login")
        Else
            Dim x As security = New security()
            Dim r As Integer = x.get_user_role(username)
            set_menus(r)
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
        initi()
        load_template_menu()
    End Sub
    Sub set_menus(ByVal mode As Integer)
        If mode = 2 Then
            look_feel.Visible = False
            tools.Visible = False
            pages.Visible = False

            settings.Visible = False
            all_posts.Visible = False
            dash.Visible = False

        ElseIf mode = 3 Then
            dash_sidebar.Visible = False
            notifi.Visible = False
        End If
    End Sub
    Sub initi()
        If x1.Get_option(23) = True Then
            Dim n As Notifications = New Notifications()

            Dim count As Integer = n.Get_notification_count(x1.GET_ID("user_info", "username", Session("name").ToString()))
            If count > 0 Then
                notifications.Text = "<li><a href='#'><div><i class='fa fa-comment fa-fw'></i>" + count.ToString() + " unread comment(s)</div></a>"
                notify.Attributes.Add("style", "color:red")
            Else
                notifications.Text = "<li><a href='#'><div>No new activities</div></a>"
            End If
        Else
            notifi.Visible = False
        End If
    End Sub
    Sub load_template_menu()
        Dim s As String = x1.Get_option(7)
        Dim path As String = Server.MapPath("~/") + "contents/templates/" + s + "/options.aspx"
        If FileIO.FileSystem.FileExists(path) Then
            tmenu.Text = "<li><a href='" + x1.Get_option(3) + "contents/templates/" + s + "/options.aspx'>Template Options</a></li>"
        End If
    End Sub
End Class



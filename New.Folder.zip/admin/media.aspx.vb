﻿
Partial Class admin_media
    Inherits System.Web.UI.Page

End Class

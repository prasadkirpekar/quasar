﻿Imports System.Data.SqlClient
Imports System.Data
Imports DatabaseQueries
Imports ContentProcessor
Imports System.Web
Partial Class admin_Posts
    Inherits System.Web.UI.Page

    Dim x As DatabaseQueries = New DatabaseQueries()
    Dim c As ContentProcessor = New ContentProcessor()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim t As String '= RouteData.Values("task")
        t = Request.QueryString("mode")
        Dim id As Integer = Request.QueryString("id")
        If t = "new" Then
            new_post.Visible = True

            load_categories()
        ElseIf t = "edit" Then
            edit_post(Request.QueryString("id"))
            new_post.Visible = True
        ElseIf t = "delete" Then
            x._delete("contents", id)
            load_post_list("All")
            all_posts.Visible = True
        Else
            all_posts.Visible = True
            If Not IsPostBack Then
                load_post_list("All")
            End If
            'test()

            End If
    End Sub

    Protected Sub publish_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles publish.Click
        If Request.QueryString("mode") = "edit" Then
            If x.update_post(Request.QueryString("id"), post_title.Text, uri.Text, x.GET_ID("categories", "title", assign_post_category.SelectedValue), content.Text, seo_title.Text, seo_meta.Text) Then
                alert.Attributes.Add("class", "alert alert-success")
                alert.InnerHtml = "Post has been updated"
            Else
                alert.Attributes.Add("class", "alert alert-danger")
                alert.InnerHtml = "Failed to update post"
            End If
        Else
            save_publish(1)
        End If
    End Sub
    Sub save_publish(ByVal mode As Integer)

        Dim dbcon As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")
        dbcon.Open()
        Dim insert_data As SqlCommand = New SqlCommand("INSERT INTO contents values(@title,@uri,@text,@st,@sm,@type,@cat_id,@comm_count,@status,@author_id,@date,@v);", dbcon)
        insert_data.Parameters.AddWithValue("@title", post_title.Text)
        Dim s As String
        If Not uri.Text = "" Then
            s = uri.Text.Replace(" ", "-")
        Else
            s = post_title.Text.Replace(" ", "-")
        End If
        
        insert_data.Parameters.AddWithValue("@uri", s)
        insert_data.Parameters.AddWithValue("@text", content.Text)
        If seo_title.Text = "" Then
            insert_data.Parameters.AddWithValue("@st", post_title.Text)
        Else
            insert_data.Parameters.AddWithValue("@st", seo_title.Text)
        End If

        insert_data.Parameters.AddWithValue("@sm", seo_meta.Text)
        insert_data.Parameters.AddWithValue("@type", 1)
        insert_data.Parameters.AddWithValue("@cat_id", x.GET_ID("categories", "title", assign_post_category.SelectedValue))
        insert_data.Parameters.AddWithValue("@comm_count", 0)
        insert_data.Parameters.AddWithValue("@status", mode)
        insert_data.Parameters.AddWithValue("@author_id", x.GET_ID("user_info", "username", Session("name").ToString()))
        insert_data.Parameters.AddWithValue("@date", Date.Now())
        insert_data.Parameters.AddWithValue("@v", 0)

        Try

            insert_data.ExecuteNonQuery()
            
            alert.Attributes.Add("class", "alert alert-success")
            alert.InnerHtml = "Post has been published <a href='" + x.Get_option(3) + s + "' target='_blank'>View here</a>"

        Catch ex As SqlException
            alert.Attributes.Clear()
            alert.InnerHtml = "Failed to create new post.Given URI might be already exist"
            alert.Attributes.Add("class", "alert alert-danger")
        End Try
    End Sub

    Protected Sub save_draft_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save_draft.Click
        save_publish(0)
    End Sub
    Sub load_post_list(ByVal mode As String)

        
        posts.Text = ""
        Dim ids As ArrayList = x.Get_Content(1, "id")
        Dim titles As ArrayList = x.Get_Content(1, "title")
        Dim uri As ArrayList = x.Get_Content(1, "uri")
        Dim cat As ArrayList = x.Get_Content(1, "cat_id")
        Dim author As ArrayList = x.Get_Content(1, "author_id")
        Dim pdate As ArrayList = x.Get_Content(1, "date")
        Dim status As ArrayList = x.Get_Content(1, "status")

        
        If mode = "All" Or mode = "all" Then
            For i As Integer = titles.Count - 1 To 0 Step -1
                posts.Text += "<tr><td><input type='checkbox'/></td><td><a href='post.aspx?mode=edit&id=" + ids(i).ToString() + "'>" + titles(i) + "</a></td><td>" + x.GET_BY_ID(author(i), "username", "user_info") + "</td><td>" + x.GET_BY_ID(cat(i), "title", "categories").ToString() + "</td><td>" + pdate(i).ToString() + "</td><td><a href='post.aspx?mode=delete&id=" + ids(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"
            Next
        ElseIf mode = "Published" Then
            For i As Integer = titles.Count - 1 To 0 Step -1
                If status(i).ToString() = "1" Then
                    posts.Text += "<tr><td><input type='checkbox'/></td><td><a href='#'>" + titles(i) + "</a></td><td>" + x.GET_BY_ID(author(i), "username", "user_info") + "</td><td>" + x.GET_BY_ID(cat(i), "title", "categories").ToString() + "</td><td>" + pdate(i).ToString() + "</td><td><a href='post.aspx?mode=delete&id=" + ids(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"
                End If
            Next
        ElseIf mode = "Drafted" Then
            For i As Integer = titles.Count - 1 To 0 Step -1
                If status(i).ToString() = "0" Then
                    posts.Text += "<tr><td><input type='checkbox'/></td><td><a href='#'>" + titles(i) + "</a></td><td>" + x.GET_BY_ID(author(i), "username", "user_info") + "</td><td>" + x.GET_BY_ID(cat(i), "title", "categories").ToString() + "</td><td>" + pdate(i).ToString() + "</td><td><a href='post.aspx?mode=delete&id=" + ids(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"
                End If
            Next
        End If


    End Sub

    Protected Sub search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles search.Click
        posts.Text = ""
        Dim result As ArrayList = New ArrayList()
        result = x.Search(1, keyword.Text.ToLower())
        Dim ids As ArrayList = New ArrayList()
        For i As Integer = 0 To result.Count - 1
            ids.Add(x.GET_ID("contents", "title", result(i)))
        Next
        Dim title As ArrayList = New ArrayList()
        Dim text As ArrayList = New ArrayList()
        Dim author As ArrayList = New ArrayList()
        Dim cat As ArrayList = New ArrayList()
        Dim page_date As ArrayList = New ArrayList()
        Dim status As ArrayList = New ArrayList()
        For i As Integer = 0 To result.Count - 1
            title.Add(x.GET_BY_ID(ids(i), "title", "contents"))
            text.Add(x.GET_BY_ID(ids(i), "ctext", "contents"))
            author.Add(x.GET_BY_ID(ids(i), "author_id", "contents"))
            page_date.Add(x.GET_BY_ID(ids(i), "date", "contents"))
            cat.Add(x.GET_BY_ID(ids(i), "cat_id", "contents"))
        Next
        For i As Integer = title.Count - 1 To 0 Step -1
            posts.Text &= "<tr><td><input id='c" + ids(i).ToString() + "' type='checkbox'/></td><td><a href='page.aspx?mode=edit&id=" + ids(i).ToString() + "'>" + title(i).ToString() + "</a></td><td>" + x.GET_BY_ID(author(i), "username", "user_info").ToString() + "</td><td>" + x.GET_BY_ID(cat(i), "title", "categories").ToString() + "</td><td>" + page_date(i).ToString() + "</td></tr>"

        Next
    End Sub
    Sub test()
        For i As Integer = 0 To x.Get_Content(1, "title").Count - 1
            Literal1.Text += x.Get_Content(1, "title").ToString()
        Next
    End Sub
    Sub load_categories()
        Dim cats As ArrayList = x.Get_categories("title")
        For i As Integer = 0 To cats.Count - 1
            assign_post_category.Items.Add(cats(i).ToString())
        Next
    End Sub

    Protected Sub new_cat_link_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles new_cat_link.Click
        Response.Redirect("~/admin/categories.aspx?mode=new")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        load_post_list(drop_type.SelectedValue)
    End Sub
    Sub edit_post(ByVal id As Integer)
        If Not IsPostBack Then
            Dim _post_title = x.GET_BY_ID(id, "title", "contents")
            Dim _post_text = x.GET_BY_ID(id, "ctext", "contents")
            Dim _post_meta = x.GET_BY_ID(id, "seo_meta", "contents")
            Dim _post_seo_title = x.GET_BY_ID(id, "seo_title", "contents")
            Dim _post_uri = x.GET_BY_ID(id, "uri", "contents")
            post_title.Text = _post_title
            content.Text = _post_text
            seo_meta.Text = _post_meta
            seo_title.Text = _post_seo_title
            uri.Text = _post_uri
            load_categories()
            publish.Text = "update"
        End If
    End Sub
End Class

﻿Imports System.Data.SqlClient
Partial Class admin_Pages
    Inherits System.Web.UI.Page
    Dim x As DatabaseQueries = New DatabaseQueries()
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        t.Text &= "<tr><td><input type='checkbox'/></td><td><a href='#'>New post</a></td><td>prasad</td><td>11/12/13</td></tr>"

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim mode As String = Request.QueryString("mode")
        Dim id As Integer = Request.QueryString("id")
        'mode = RouteData.Values("_pagetask")
        If mode = "new" Then
            new_page.Visible = True
        ElseIf mode = "edit" Then

            edit_post(id)
            new_page.Visible = True
            publish.Text = "Update"
        ElseIf mode = "all" Then
            all_pages.Visible = True
            load_pages("All")
        ElseIf mode = "delete" Then
            x._delete("contents", id)
            all_pages.Visible = True
        Else
            all_pages.Visible = True
        End If
        Dim dbc As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")
        Try
            dbc.Open()
        Catch ex As SqlException
            Response.Redirect("~/installer.aspx")
        End Try
    End Sub

    Protected Sub publish_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles publish.Click
        If Request.QueryString("mode") = "edit" Then
            If x.Update_page(Request.QueryString("id"), page_title.Text, uri.Text.Replace(" ", "-"), page_text.Text, seo_title.Text, seo_meta.Text) Then
                alert.Text = "done"
            Else
                alert.Text = "failed"
            End If
        Else
            save_publish_page(1)
        End If
    End Sub
    Sub save_publish_page(ByVal mode As Integer)
       
        
            Dim dbcon As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")

            Dim publish_comm As SqlCommand = New SqlCommand("insert into contents values(@title,@uri,@ctext,@st,@sm,@ctype,@cat_id,@comm_count,@status,@author_id,@date,@views)", dbcon)
            publish_comm.Parameters.AddWithValue("@title", page_title.Text)
        publish_comm.Parameters.AddWithValue("@uri", uri.Text.Replace(" ", "-"))
            publish_comm.Parameters.AddWithValue("@ctext", page_text.Text)
            publish_comm.Parameters.AddWithValue("@st", seo_title.Text)
            publish_comm.Parameters.AddWithValue("@sm", seo_meta.Text)
            publish_comm.Parameters.AddWithValue("@ctype", 2)
            publish_comm.Parameters.AddWithValue("@cat_id", "")
            publish_comm.Parameters.AddWithValue("@comm_count", "")
            publish_comm.Parameters.AddWithValue("@status", mode)
            publish_comm.Parameters.AddWithValue("@author_id", 1)
            publish_comm.Parameters.AddWithValue("@date", DateTime.Now())
            publish_comm.Parameters.AddWithValue("@views", 0)
            Try
                dbcon.Open()
                publish_comm.ExecuteNonQuery()
                alert.Text = "done"
            Catch ex As SqlException
                alert.Text = "failed"
            End Try

    End Sub

    Protected Sub save_draft_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save_draft.Click
        save_publish_page(0)
    End Sub
    Sub load_pages(ByVal mode As String)
        t.Text = ""
        Dim pages_title As ArrayList = New ArrayList()
        Dim pages_id As ArrayList = New ArrayList()
        Dim pages_author As ArrayList = New ArrayList()
        Dim pages_date As ArrayList = New ArrayList()
        Dim pages_status As ArrayList = New ArrayList()
        pages_title = x.Get_Content(2, "title")
        pages_id = x.Get_Content(2, "id")
        pages_author = x.Get_Content(2, "author_id")
        pages_date = x.Get_Content(2, "date")
        pages_status = x.Get_Content(2, "status")
        If mode = "All" Then

            For i As Integer = pages_title.Count - 1 To 0 Step -1
                t.Text &= "<tr><td><input id='c" + i.ToString() + "' type='checkbox'/></td><td><a href='page.aspx?mode=edit&id=" + pages_id(i).ToString() + "'>" + pages_title(i).ToString() + "</a></td><td>" + x.GET_BY_ID(pages_author(i), "username", "user_info").ToString() + "</td><td>" + pages_date(i).ToString() + "</td><td><a href='page.aspx?mode=delete&id=" + pages_id(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"

            Next
        ElseIf mode = "Drafted" Then
            For i As Integer = pages_title.Count - 1 To 0 Step -1
                If pages_status(i).ToString() = "0" Then
                    t.Text &= "<tr><td><input id='c" + i.ToString() + "' type='checkbox'/></td><td><a href='page.aspx?mode=edit&id=" + pages_id(i).ToString() + "'>" + pages_title(i).ToString() + "</a></td><td>" + x.GET_BY_ID(pages_author(i), "username", "user_info").ToString() + "</td><td>" + pages_date(i).ToString() + "</td><td><a href='page.aspx?mode=delete&id=" + pages_id(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"
                End If
            Next
            page_list.SelectedIndex = 2
        ElseIf mode = "Published" Then
            For i As Integer = pages_title.Count - 1 To 0 Step -1
                If pages_status(i).ToString() = "1" Then
                    t.Text &= "<tr><td><input id='c" + i.ToString() + "' type='checkbox'/></td><td><a href='page.aspx?mode=edit&id=" + pages_id(i).ToString() + "'>" + pages_title(i).ToString() + "</a></td><td>" + x.GET_BY_ID(pages_author(i), "username", "user_info").ToString() + "</td><td>" + pages_date(i).ToString() + "</td><td><a href='page.aspx?mode=delete&id=" + pages_id(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"
                End If
            Next
            page_list.SelectedIndex = 3
        End If
    End Sub
    Sub edit_post(ByVal id As Integer)
        If Not IsPostBack Then
            Dim _page_title = x.GET_BY_ID(id, "title", "contents")
            Dim _page_text = x.GET_BY_ID(id, "ctext", "contents")
            Dim _page_meta = x.GET_BY_ID(id, "seo_meta", "contents")
            Dim _page_seo_title = x.GET_BY_ID(id, "seo_title", "contents")
            Dim _page_uri = x.GET_BY_ID(id, "uri", "contents")
            page_text.Text = _page_text
            page_title.Text = _page_title
            seo_meta.Text = _page_meta
            seo_title.Text = _page_seo_title
            uri.Text = _page_uri
        End If
    End Sub

    Protected Sub look_for_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles look_for.Click
        load_pages(page_list.SelectedValue)

    End Sub

    Protected Sub search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles search.Click
        t.Text = ""
        Dim result As ArrayList = New ArrayList()
        result = x.Search(2, search_term.Text.ToLower())
        Dim ids As ArrayList = New ArrayList()
        For i As Integer = 0 To result.Count - 1
            ids.Add(x.GET_ID("contents", "title", result(i)))
        Next
        Dim title As ArrayList = New ArrayList()
        Dim text As ArrayList = New ArrayList()
        Dim author As ArrayList = New ArrayList()
        Dim page_date As ArrayList = New ArrayList()
        Dim status As ArrayList = New ArrayList()
        For i As Integer = 0 To result.Count - 1
            title.Add(x.GET_BY_ID(ids(i), "title", "contents"))
            text.Add(x.GET_BY_ID(ids(i), "ctext", "contents"))
            author.Add(x.GET_BY_ID(ids(i), "author_id", "contents"))
            page_date.Add(x.GET_BY_ID(ids(i), "date", "contents"))
        Next
        For i As Integer = title.Count - 1 To 0 Step -1
            t.Text &= "<tr><td><input id='c" + ids(i).ToString() + "' type='checkbox'/></td><td><a href='page.aspx?mode=edit&id=" + ids(i).ToString() + "'>" + title(i).ToString() + "</a></td><td>" + x.GET_BY_ID(author(i), "username", "user_info").ToString() + "</td><td>" + page_date(i).ToString() + "</td></tr>"

        Next
    End Sub
End Class

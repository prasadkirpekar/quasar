﻿
Partial Class admin_lost
    Inherits System.Web.UI.Page

End Class

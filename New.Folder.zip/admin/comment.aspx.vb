﻿
Partial Class admin_Comments
    Inherits System.Web.UI.Page
    Dim x As DatabaseQueries = New DatabaseQueries()
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("../admin/newcomment.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim mode As String = Request.QueryString("mode")
        Dim action As String = Request.QueryString("action")
        Dim id As Integer = Request.QueryString("id")
        If action = "live" Then
            x.update_status("comments", id, 1)
        ElseIf action = "spam" Then
            x.update_status("comments", id, 0)
        ElseIf action = "delete" Then
            x._delete("comments", id)
        End If
        If mode = "new" Then
            new_comment.Visible = True
            initi()
        ElseIf mode = "all" Then
            all_comments.Visible = True
            load_comments()
        Else
            all_comments.Visible = True
            load_comments()
        End If
    End Sub
    Sub load_comments()
        Dim com_text As ArrayList = x.Get_comments("comment")
        Dim com_author As ArrayList = x.Get_comments("cauthor")
        Dim p_id As ArrayList = x.Get_comments("post_id")
        Dim dte As ArrayList = x.Get_comments("date")
        Dim status As ArrayList = x.Get_comments("status")
        Dim ids As ArrayList = x.Get_comments("id")
        For i As Integer = com_text.Count - 1 To 0 Step -1
            t.Text += "<tr><td><input id=c" + ids(i).ToString() + " type='checkbox'/></td><td>" + com_text(i).ToString() + "</td><td>" + com_author(i).ToString() + "</td><td>" + x.GET_BY_ID(p_id(i), "title", "contents").ToString() + "</td><td>" + dte(i).ToString() + "</td><td>"
            If status(i).ToString() = "1" Then
                t.Text += "<a href='comment.aspx?action=live&id=" + ids(i).ToString() + "'><b>Live</b></a>"
            Else
                t.Text += "<a href='comment.aspx?action=live&id=" + ids(i).ToString() + "'>Live</a>"
            End If
            If status(i).ToString() = "0" Then
                t.Text += "/ <a href='comment.aspx?action=spam&id=" + ids(i).ToString() + "'><b>Spam</b></a>"
            Else
                t.Text += "/ <a href='comment.aspx?action=spam&id=" + ids(i).ToString() + "'>Spam</a>"

            End If
            t.Text += "/ <a href='comment.aspx?action=delete&id=" + ids(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"
        Next

    End Sub
    Sub initi()
        Dim posts As ArrayList = x.Get_Content(1, "title")
        Dim status As ArrayList = x.Get_Content(1, "status")
        For i As Integer = posts.Count - 1 To 0 Step -1
            If status(i) = "1" Then
                post_to_comment_on.Items.Add(posts(i))
            End If
        Next
    End Sub

    Protected Sub save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save.Click
        Dim titles As ArrayList = x.Get_Content(1, "title")
        Dim uris As ArrayList = x.Get_Content(1, "uri")
        For i As Integer = 0 To titles.Count - 1
            If titles(i).ToString() = post_to_comment_on.SelectedValue Then
                If x.Add_Comment(uris(i).ToString(), name.Text, email.Text, comment.Text, 1) Then
                    alert.Text = "done"
                End If
            End If
        Next
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click

    End Sub
End Class

﻿Imports System.Data.SqlClient
Partial Class admin_user
    Inherits System.Web.UI.Page
    Dim x As DatabaseQueries = New DatabaseQueries()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim type As String = Request.QueryString("type")
        If type = "all" Then
            If Not IsPostBack Then
                load_users("f")
            End If

            all_user.Visible = True
        ElseIf type = "new" Then
            new_user.Visible = True
        Else
            my_profile.Visible = True
        End If
        If Not IsPostBack Then
            Dim un As String = Session("name")
            username.Text = un
            email.Text = x.GET_BY_ID(x.GET_ID("user_info", "username", un), "email", "user_info")
            Dim i As Integer = x.GET_BY_ID(x.GET_ID("user_info", "username", un), "role", "user_info")
            avatar.ImageUrl = x.GET_BY_ID(x.GET_ID("user_info", "username", un), "avatar", "user_info")
            If i = 1 Then
                user_role.Items.Add("Administrator")
                user_role.Items.Add("Contributor")
                user_role.Items.Add("Subscriber")
            ElseIf i = 2 Then
                user_role.Items.Add("Contributor")
            Else
                user_role.Items.Add("Subscriber")
            End If

        End If
    End Sub

    Protected Sub save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save.Click
        Dim role As Integer
        Dim ui As ArrayList = New ArrayList()
        If user_role.SelectedValue = "Administrator" Then
            role = 1
        ElseIf user_role.SelectedValue = "Contributor" Then
            role = 2
        Else
            role = 3
        End If
        Dim pass As String = ""
        If password.Text = conf_password.Text Then
            If conf_password.Text = "" Then
                ui = x.Get_USER_INFO(Session("name"))
                pass = ui(2)
            End If
        Else
            alert.Text = "Password mismatch!"
            Exit Sub
        End If
        If x.Update_user(Session("name"), email.Text, pass, role) Then
            alert.Text = "done"
        Else
            alert.Text = "failed"
        End If
    End Sub
    Sub load_users(ByVal mode As String)
        Dim u As ArrayList = x.Get_users("username")
        Dim e As ArrayList = x.Get_users("email")
        Dim r As ArrayList = x.Get_users("role")
        Dim pc As ArrayList = x.Get_users("post_count")

        For i As Integer = u.Count - 1 To 0 Step -1
            t.Text += "<tr><td><input type='checkbox'/></td><td>" + u(i).ToString() + "</td><td>" + e(u.Count - 1 - i).ToString() + "</td><td>" + pc(i).ToString() + "</td><td>" + r(i).ToString() + "</td></tr>"
        Next
    End Sub

    Protected Sub new_user_add_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles new_user_add.Click
        If x.ADD_USER(new_u.Text, new_p.Text, new_e.Text, new_role.SelectedValue) Then
            alert.Text = "Done"
        Else
            alert.Text = "Failed! Username might be alredy exist <a href='user.aspx?type=all'>check here</a>"
        End If

    End Sub

    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button5.Click
        Response.Redirect("~/admin/user.aspx?type=new")
    End Sub

    Protected Sub upload_a_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles upload_a.Click
        Dim path As String = ""
        If new_avatar.HasFile Then
            path = Server.MapPath("~/") + "contents\uploads\a\" + Session("name").ToString() + ".png"
            new_avatar.SaveAs(path)
        Else
            alert.Text = "Select correct file"
        End If
        If Not path = "" Then
            path = x.Get_option(3) + "contents/uploads/a/" + Session("name").ToString() + ".png"
            If x.update_avatar(path, Session("name")) Then
                alert.Text = "avatar uploaded <a href='user.aspx'>Refresh to see changes</a>"
            Else
                alert.Text = "Failed to uploaded"
            End If
        End If
    End Sub

    Protected Sub delete_avatar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles delete_avatar.Click
        If x.update_avatar(x.Get_option(3) + "contents/uploads/a/default.png", Session("name")) Then
            alert.Text = "Avatar removed <a href='user.aspx'>Refresh to see changes</a>"
        End If
    End Sub
End Class

﻿Imports System.Linq
Imports System.IO.File
Partial Class admin_Export
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim f As FileIO.FileSystem = New FileIO.FileSystem()
        FileIO.FileSystem.CopyFile(Server.MapPath("~/app_data/database.mdf"), Server.MapPath("~/database.bak"))
    End Sub
End Class

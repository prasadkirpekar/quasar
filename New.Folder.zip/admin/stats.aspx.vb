﻿Imports System.Web.Services

Partial Class admin_stats
    Inherits System.Web.UI.Page
    <WebMethod()> Function get_today() As String
        Return DateTime.Today.ToShortDateString()
    End Function
End Class

﻿
Partial Class admin_notifications
    Inherits System.Web.UI.Page
    Dim x As DatabaseQueries = New DatabaseQueries()
    Sub load_notifications(ByVal mode As String)
        Dim noti_text As ArrayList = x.Get_notifications(1, "text")
        Dim noti_status As ArrayList = x.Get_notifications(1, "status")
        Dim noti_id As ArrayList = x.Get_notifications(1, "id")
        For i As Integer = noti_text.Count - 1 To 0 Step -1
            If noti_status(i).ToString() = "1" Then
                t.Text += "<tr><td><input type='checkbox'/></td><td>" + noti_text(i).ToString() + "</td><td><a href='notifications.aspx?action=markread&id=" + noti_id(i).ToString() + "'>Mark read</a> / <a href='notifications.aspx?action=delete&id=" + noti_id(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"
            Else
                t.Text += "<tr><td><input type='checkbox'/></td><td>" + noti_text(i).ToString() + "</td><td><a href='notifications.aspx?action=markunread&id=" + noti_id(i).ToString() + "'>Mark Unread</a> / <a href='notifications.aspx?action=delete&id=" + noti_id(i).ToString() + "'><span style='color:red'>Delete</span></a></td></tr>"
            End If

        Next
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim action As String = Request.QueryString("action")
        Dim id As Integer = Request.QueryString("id")
        If action = "markread" Then
            x.update_status("notifications", id, 0)
        ElseIf action = "markunread" Then
            x.update_status("notifications", id, 1)
        ElseIf action = "delete" Then
            x._delete("notifications", id)
        End If
        load_notifications("d")
    End Sub
End Class

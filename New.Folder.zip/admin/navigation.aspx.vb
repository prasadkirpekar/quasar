﻿
Partial Class admin_Navigation
    Inherits System.Web.UI.Page

    Dim x As DatabaseQueries = New DatabaseQueries()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            load_controls()
            load_menu_items()
        End If

    End Sub
    Sub load_controls()
        Dim posts As ArrayList = x.Get_Content(1, "title")
        Dim status As ArrayList = x.Get_Content(1, "status")
        Dim post_slug As ArrayList = x.Get_Content(1, "uri")
        Dim page_slug As ArrayList = x.Get_Content(2, "uri")
        Dim pages As ArrayList = x.Get_Content(2, "title")
        Dim page_stat As ArrayList = x.Get_Content(2, "status")
        Dim site_url As String = x.Get_option(3)
        For i As Integer = posts.Count - 1 To 0 Step -1
            If status(i).ToString() = "1" Then
                post_list.Items.Add(posts(i))
            End If
        Next
        For i As Integer = pages.Count - 1 To 0 Step -1
            If page_stat(i).ToString() = "1" Then
                page_list.Items.Add(pages(i))
            End If
        Next
        Dim menus As ArrayList = x.Get_menus("name")
        For i As Integer = menus.Count - 1 To 0 Step -1
            menulist.Items.Add(menus(i).ToString())
        Next
        menu_name.Text = x.Get_option(8)
        alert.Text = "Current menu is " + x.Get_option(8)
    End Sub
    Sub load_menu_items()
        Dim t As Template = New Template()
        Dim m As ArrayList = t.get_menu_titles()
        navpr.Items.Clear()
        For i As Integer = 0 To m.Count - 1
            navpr.Items.Add(m(i))
        Next
    End Sub


    Protected Sub add_post_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles add_post.Click
        navpr.Items.Add(post_list.SelectedValue().ToString())
    End Sub

    Protected Sub remove_item_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles remove_item.Click
        navpr.Items.Remove(navpr.SelectedValue().ToString())
    End Sub

    Protected Sub add_page_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles add_page.Click
        navpr.Items.Add(page_list.SelectedValue().ToString())
    End Sub


    Protected Sub save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save.Click
        Dim titles As String = ""
        Dim uris As String = ""
        Dim final As ArrayList = New ArrayList()
        For i As Integer = 0 To navpr.Items.Count - 1
            titles += navpr.Items(i).ToString() + ","
        Next
        For i As Integer = 0 To navpr.Items.Count - 1
            uris += x.GET_BY_ID(x.GET_ID("contents", "title", navpr.Items(i).ToString()), "uri", "contents") + ","
        Next

        final.Add(menu_name.Text)
        final.Add(titles)
        final.Add(uris)
        If x.Put_data("nav", final) Then
            alert.Text = "done"
        ElseIf x.update_menu(menu_name.Text, titles, uris) Then
            alert.Text = "menu updated"
        Else
            alert.Text = "failed"
        End If
    End Sub

    Protected Sub set_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles [set].Click
        If x.Add_option(8, menulist.SelectedValue.ToString()) Then
            alert.Text = "Navigation updated current menu is " + menulist.SelectedValue.ToString()
            load_menu_items()
        End If
    End Sub
End Class

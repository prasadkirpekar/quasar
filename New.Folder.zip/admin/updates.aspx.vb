﻿
Partial Class admin_updates
    Inherits System.Web.UI.Page

End Class

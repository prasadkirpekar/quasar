﻿Imports ContentProcessor
Imports security
Imports System.IO
Partial Class admin_templates
    Inherits System.Web.UI.Page

    Dim x As DatabaseQueries = New DatabaseQueries
    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim mode As String = Request.QueryString("mode")
        If mode = "new" Then
            [new].Visible = True
            user_alert.Text = "Select template package (.zip file)"
       
        Else
            all.Visible = True
            If Not IsPostBack Then
                load_templates()
            End If
            End If
    End Sub

    Protected Sub add_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles add.Click
        If template_to_import.HasFile Then

            Dim filename As String = template_to_import.FileName
            template_to_import.SaveAs(Server.MapPath("~/admin/temp/") & filename)

            Dim t As ContentProcessor = New ContentProcessor
              t.unzip_(Server.MapPath("~/admin/temp/") & template_to_import.FileName.ToString(), Server.MapPath("~/contents/templates/"))

            user_alert.Text = "Template " & filename & " uploaded successfully <a href='../contents/templates/" + filename.TrimEnd(".") + "/install.aspx'> Click here to install</a>"
            user_alert_style.Attributes.Add("class", "alert alert-success")
        Else
            user_alert.Text = "template not detected, select valid .zip file"
            user_alert_style.Attributes.Add("class", "alert alert-danger")

        End If
    End Sub
    Sub load_templates()
        temp_alert.Text = "Current templalate " + x.Get_option(7)
        Dim t As Array = Directory.GetDirectories(Server.MapPath("~/contents/templates"))
        Dim x1 As ContentProcessor = New ContentProcessor()

        For i As Integer = 0 To t.Length - 1
            templates.Items.Add(x1.Get_name(t(i)))
        Next
    End Sub

    Protected Sub select_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles [select].Click

        Dim t As String = templates.SelectedValue
        temp_alert.Visible = True
        If x.Add_option(7, t) = False Then

            temp_alert.Text = "Failed to update settings"
        Else
            temp_alert.Text = "Settings saved! Current template " + t
        End If
    End Sub
End Class

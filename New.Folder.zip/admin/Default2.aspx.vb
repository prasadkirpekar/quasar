﻿
Partial Class admin_Default2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim x As DatabaseQueries = New DatabaseQueries
        views_.Text = "67"
        Dim t As Template = New Template()
        Dim a1 As ArrayList = New ArrayList()
        Dim a2 As ArrayList = New ArrayList()
        Dim a3 As ArrayList = New ArrayList()
        a1.Add("id")
        a2.Add("int")
        a3.Add("primary key")
        If t.add_table("bricks", a1, a2, a3) Then
            views_.Text = "done"
        Else
            views_.Text = "failed"
        End If
    End Sub
End Class

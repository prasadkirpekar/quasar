﻿
Partial Class contents_templates_retro_index
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If RouteData.Values("type").ToString.ToLower() = "post" And RouteData.Values("query").ToString.ToLower() = "all" Then
            post_list.Visible = True
        End If
        If RouteData.Values("type") Is Nothing And RouteData.Values("query") Is Nothing Then
            post_list.Visible = True
        End If

    End Sub
End Class

﻿Imports System.Web.Routing
Partial Class contents_templates_retro_parent
    Inherits System.Web.UI.MasterPage
    Dim x As DatabaseQueries = New DatabaseQueries()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        load_homescreen()
    End Sub
    Sub load_homescreen()
        If x.Get_option(17) = "None" Then
            normal.Visible = False
            landing_page.Visible = True
        Else
            normal.Visible = True
            landing_page.Visible = False
        End If
    End Sub
End Class


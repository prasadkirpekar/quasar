﻿
Partial Class contents_templates_retro_options
    Inherits System.Web.UI.Page
    Dim x As Template = New Template()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If x.is_installed("retro") Then
            options.Enabled = True
        End If
    End Sub

    Protected Sub save_retro_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles save_retro.Click
        Dim v1 As ArrayList = New ArrayList()
        Dim v2 As ArrayList = New ArrayList()
        Dim v3 As ArrayList = New ArrayList()
        Dim v4 As ArrayList = New ArrayList()
        Dim v5 As ArrayList = New ArrayList()
        v1.Add(w_icon.Text)
        v2.Add(w_title.Text)
        v3.Add(w_descr.Text)
        v4.Add(w_b_title.Text)
        v5.Add(w_b_link.Text)
        If x.update_data(4, "retro", "value", v4) And x.update_data(5, "retro", "value", v5) And x.update_data(1, "retro", "value", v1) And x.update_data(2, "retro", "value", v2) And x.update_data(3, "retro", "value", v3) Then
            alert.Text = "Template settings are updated"
        End If
    End Sub
End Class

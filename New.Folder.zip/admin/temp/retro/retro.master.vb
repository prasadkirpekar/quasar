﻿
Partial Class contents_templates_retro_retro
    Inherits System.Web.UI.MasterPage
    Dim t As Template = New Template()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        w_i.Attributes.Add("class", "icon " + t.get_value_by_id(1, "retro", "value"))
    End Sub
End Class


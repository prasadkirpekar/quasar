﻿
Partial Class contents_templates_retro_single
    Inherits System.Web.UI.Page
    Dim x As DatabaseQueries = New DatabaseQueries()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim t As Integer = Request.QueryString().Count

        If RouteData.Values("post") = "index" Then
            post_list.Visible = True
        Else
            _load(RouteData.Values("post").ToString())
            If Not IsPostBack Then
                load_comments(RouteData.Values("post"))
            End If
        End If
    End Sub
    Sub _load(ByVal uri As String)
        If Not x.GET_ID("contents", "uri", uri).ToString() = "0" Then
            _title.Text = x.GET_BY_ID(x.GET_ID("contents", "uri", uri), "title", "contents")
            ctext.Text = x.GET_BY_ID(x.GET_ID("contents", "uri", uri), "ctext", "contents")
            meta.Text = x.GET_BY_ID(x.GET_BY_ID(x.GET_ID("contents", "uri", uri), "author_id", "contents"), "username", "user_info").ToString()
            If x.GET_BY_ID(x.Get_POST_ID(RouteData.Values("post")), "ctype", "contents").ToString() = "1" Then
                post_panel.Visible = True

            End If
            the_post.Visible = True
        Else
            _title.Text = x.Get_option(13)
            ctext.Text = x.GET_BY_ID(x.GET_ID("contents", "title", _title.Text), "ctext", "contents")
            post_panel.Visible = True
            the_post.Visible = True
        End If
    End Sub

    Protected Sub add_com_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles add_com.Click
        Dim n_text As String = name.Text + " is commented on " + x.GET_BY_ID(x.Get_POST_ID(RouteData.Values("post")), "title", "contents").ToString() + " at " + Date.Now() + " " + TimeOfDay()
        Dim n As Notifications = New Notifications()

        If x.Add_Comment(RouteData.Values("post"), name.Text, email.Text, comment.Text, x.Get_option(4)) And n.Add_notification(1, n_text, 1, Convert.ToInt16(x.GET_BY_ID(x.GET_ID("contents", "uri", RouteData.Values("post")), "author_id", "contents"))) Then
            If x.Get_option(4).ToString() = "0" Then
                Label1.Text = "Comment added,and waiting for moderation"
            Else
                Label1.Text = "Comment Successful"
            End If
        Else
            Label1.Text = "Failed to add"
        End If
    End Sub
    Sub load_comments(ByVal uri As String)
        _comments.Text = ""
        Dim comments As ArrayList = x.GET_COMMENTS_OF(x.GET_ID("contents", "uri", RouteData.Values("post")))
        For i As Integer = comments.Count - 4 To 0 Step -4
            _comments.Text += comments(i).ToString() + "<br/>by <a href='mailto:" + comments(i + 2).ToString() + "'>" + comments(i + 1).ToString() + "</a> posted at " + comments(i + 3).ToString() + "<br/><hr/>"
        Next
        If _comments.Text = "" Then
            _comments.Text = "No comments"
        End If
    End Sub
    Sub load_homescreen()
        If Not x.Get_option(17) = "None" Then
            
        End If
    End Sub
End Class

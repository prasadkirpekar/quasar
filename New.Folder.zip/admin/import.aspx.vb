﻿
Partial Class admin_Import
    Inherits System.Web.UI.Page


    Protected Sub import_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles import.Click
        If (file_to_import.HasFile) Then
            Dim file_name As String = file_to_import.FileName
            file_to_import.SaveAs(Server.MapPath("~/") & "uploads/" & file_name)




           
        End If

    End Sub

End Class

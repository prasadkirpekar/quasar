﻿
Partial Class admin_custom
    Inherits System.Web.UI.Page

End Class

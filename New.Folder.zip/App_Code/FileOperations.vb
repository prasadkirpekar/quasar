﻿Imports Microsoft.VisualBasic
Imports System.IO
Imports DatabaseQueries
Imports System.Web.UI
Public Class FileOperations
    Dim x As DatabaseQueries = New DatabaseQueries()
    Function Get_gadgets(ByVal s As String) As ArrayList
        Dim gadgets As ArrayList = New ArrayList()
        Dim glist As Array = Directory.GetFiles(s)
        For i As Integer = 0 To glist.Length - 1
            gadgets.Add(glist(i))
        Next
        Return gadgets
    End Function
    Function _upload(ByVal uploader_object As FileUpload, ByVal file_path As String) As String
        Dim target_url As String = ""
        If uploader_object.HasFile Then
            Dim path As String = file_path + "contents\uploads\" + uploader_object.FileName.ToString().Replace(" ", "-")
            uploader_object.SaveAs(path)
            target_url = x.Get_option(3) + "contents/uploads/" + uploader_object.FileName.ToString().Replace(" ", "-")
            Return target_url
        Else
            Return ""
        End If

    End Function
End Class

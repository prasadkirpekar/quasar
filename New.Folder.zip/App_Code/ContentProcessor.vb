﻿Imports Microsoft.VisualBasic

Public Class ContentProcessor
    Public Function add_hashtag(ByVal text As String) As String
        Dim tag As String = ""
        Dim t As Integer = 0
        Dim tag_pos As Integer
        For i As Integer = 0 To text.Length
            If text.ElementAt(i) = "#" Then
                tag_pos = i
                Do
                    t = 0
                    tag.Insert(t, text.ElementAt(i + 1))
                    t = t + 1
                Loop Until text.ElementAt(i) = " "
            End If
        Next
        Return "<a href=" & tag & "></a>"
    End Function
    
    Function Get_name(ByVal s As String) As String
        Dim p As Integer
        For i As Integer = 0 To s.Length - 1 Step 1
            If s.ElementAt(i) = "\" Then
                p = i
            End If
        Next
        Return s.Substring(p + 1)
    End Function
    Function Search_substring(ByVal str As String, ByVal s As String) As Integer
        Return str.IndexOf(s)
    End Function

    Sub unzip_(ByVal p1 As String, ByVal p2 As String)
        Dim t As ICSharpCode.SharpZipLib.Zip.FastZip = New ICSharpCode.SharpZipLib.Zip.FastZip()
        t.ExtractZip(p1, p2, "")
    End Sub

End Class

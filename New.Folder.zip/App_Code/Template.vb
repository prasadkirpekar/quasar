﻿Imports Microsoft.VisualBasic
Imports DatabaseQueries

Public Class Template
    Dim x As DatabaseQueries = New DatabaseQueries()
    Function get_title() As String
        Return x.Get_option(1)
    End Function
    Function get_description() As String
        Return x.Get_option(2)
    End Function
    Function get_site_url() As String
        Return x.Get_option(3)
    End Function
    Function search(ByVal q As String) As ArrayList
        Dim r As ArrayList = x.Search(1, q)
        Return r
    End Function
    Function get_post_titles() As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim titles As ArrayList = x.Get_Content(1, "title")
        Dim status As ArrayList = x.Get_Content(1, "status")
        For i As Integer = titles.Count - 1 To 0 Step -1
            If status(i).ToString() = "1" Then
                r.Add(titles(i))
            End If
        Next
        Return r
    End Function
    Function get_post_text() As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim text As ArrayList = x.Get_Content(1, "ctext")
        Dim status As ArrayList = x.Get_Content(1, "status")
        For i As Integer = text.Count - 1 To 0 Step -1
            If status(i).ToString() = "1" Then
                r.Add(text(i))
            End If
        Next
        Return r
    End Function
    Function get_post_uris() As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim uris As ArrayList = x.Get_Content(1, "uri")
        Dim status As ArrayList = x.Get_Content(1, "status")
        For i As Integer = uris.Count - 1 To 0 Step -1
            If status(i).ToString() = "1" Then
                r.Add(uris(i))
            End If
        Next
        Return r
    End Function
    Function get_post_author() As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim authors As ArrayList = x.Get_Content(1, "author_id")
        Dim status As ArrayList = x.Get_Content(1, "status")
        For i As Integer = authors.Count - 1 To 0 Step -1
            If status(i).ToString() = "1" Then
                r.Add(x.GET_BY_ID(authors(i), "username", "user_info"))
            End If
        Next
        Return r
    End Function
    Function get_categories() As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim cats As ArrayList = x.Get_categories("title")

        For i As Integer = cats.Count - 1 To 0 Step -1
            r.Add(cats(i))
        Next
        Return r
    End Function
    Function get_category_description(ByVal category As String) As String
        Return x.GET_BY_ID(x.GET_ID("categories", "title", category), "description", "categories")
    End Function
    Function get_post_titles_by_category(ByVal category As String) As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim titles As ArrayList = x.Get_Content(1, "title")
        Dim cat_ids As ArrayList = x.Get_Content(1, "cat_id")
        Dim a, b As String
        For i As Integer = titles.Count - 1 To 0 Step -1
            a = x.GET_BY_ID(cat_ids(i), "title", "categories").ToString()
            b = category
            If a = b Then
                r.Add(titles(i).ToString())
            End If
        Next
        Return r
    End Function
    Function get_post_uri_by_category(ByVal category As String) As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim uris As ArrayList = x.Get_Content(1, "uri")
        Dim cat_ids As ArrayList = x.Get_Content(1, "cat_id")
        For i As Integer = uris.Count - 1 To 0 Step -1
            If x.GET_BY_ID(cat_ids(i), "title", "categories").ToString() = category Then
                r.Add(uris(i).ToString())
            End If
        Next
        Return r
    End Function
    Function get_post_text_by_category(ByVal category As String) As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim ctext As ArrayList = x.Get_Content(1, "ctext")
        Dim cat_ids As ArrayList = x.Get_Content(1, "cat_id")
        For i As Integer = ctext.Count - 1 To 0 Step -1
            If x.GET_BY_ID(cat_ids(i), "title", "categories").ToString() = category Then
                r.Add(ctext(i).ToString())
            End If
        Next
        Return r
    End Function
    Function get_menu_titles() As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim s As String = x.GET_BY_ID(x.GET_ID("nav", "name", x.Get_option(8)), "titles", "nav")
        Dim list As Array = s.Split(",")
        For i As Integer = 0 To list.Length - 2
            r.Add(list(i))
        Next
        Return r
    End Function
    Function get_menu_urls() As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim s As String = x.GET_BY_ID(x.GET_ID("nav", "name", x.Get_option(8)), "url", "nav")
        Dim list As Array = s.Split(",")
        For i As Integer = 0 To list.Length - 2
            r.Add(x.Get_option(3) + list(i))
        Next
        Return r
    End Function
    Function add_table(ByVal name As String, ByVal columns As ArrayList, ByVal datatypes As ArrayList, ByVal keys As ArrayList) As Boolean
        Dim r As Boolean
        r = x.create_table(name, columns, datatypes, keys)
        Return r
    End Function
    Function insert_to_table(ByVal table_name As String, ByVal table_row As ArrayList) As Boolean
        Return x.Put_data(table_name, table_row)
    End Function
    Function update_data(ByVal id As Integer, ByVal table As String, ByVal column_name As String, ByVal value As ArrayList) As Boolean
        Return x._update(id, table, column_name, value)
    End Function
    Function get_row_id(ByVal table As String, ByVal column_name As String, ByVal unique_value As String) As Integer
        Return x.GET_ID(table, column_name, unique_value)
    End Function
    Function get_value_by_id(ByVal id As Integer, ByVal table_name As String, ByVal column As String) As String
        Return x.GET_BY_ID(id, column, table_name)
    End Function
    Function delete_row(ByVal table As String, ByVal row_id As Integer) As Boolean
        Return x._delete(table, row_id)
    End Function
    Function register_template(ByVal template_name As String) As Boolean

        Return x.register_template(template_name)
    End Function
    Function is_installed(ByVal template_name As String) As Boolean
        Return x.GET_WITHOUT_ID("templates", "is_installed", template_name, "name")
    End Function
    Function get_post_dates() As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim dates As ArrayList = x.Get_Content(1, "date")
        Dim status As ArrayList = x.Get_Content(1, "status")
        For i As Integer = dates.Count - 1 To 0 Step -1
            If status(i).ToString() = "1" Then
                r.Add(dates(i))
            End If
        Next
        Return r
    End Function

End Class

﻿Imports Microsoft.VisualBasic
Imports System.Web.Routing.RouteTable
Imports System.Data.SqlClient
Imports System.Web.Routing
Imports ContentProcessor

Public Class DatabaseQueries
    Dim c As ContentProcessor = New ContentProcessor()
    Dim _cs As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;Connect Timeout=30;User Instance=true"
    Public Function Get_menus(ByVal column As String) As ArrayList
        Dim r As ArrayList = New ArrayList()
        Dim com As SqlCommand = New SqlCommand("select " + column + " from nav", New SqlConnection(_cs))
        Try
            com.Connection.Open()
            Dim recs As SqlDataReader = com.ExecuteReader()
            While recs.Read()
                r.Add(recs(column))
            End While
        Catch ex As Exception
            Return r
        End Try

        Return r
    End Function
    Public Function Add_Comment(ByVal uri As String, ByVal n As String, ByVal e As String, ByVal c As String, ByVal status As Integer) As Boolean
        Dim add_c As SqlCommand = New SqlCommand("insert into comments values(@c,@ca,@ce,@pi,@d,@s)", New SqlConnection(_cs))
        add_c.Parameters.AddWithValue("@c", c)
        add_c.Parameters.AddWithValue("@ca", n)
        add_c.Parameters.AddWithValue("@ce", e)
        add_c.Parameters.AddWithValue("@pi", Get_POST_ID(uri))
        add_c.Parameters.AddWithValue("@d", DateTime.Now().ToString())
        add_c.Parameters.AddWithValue("@s", status)
        add_c.Connection.Open()
        Dim r As Boolean
        Try

            add_c.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    Function Get_POST_ID(ByVal slug As String) As Integer

        Dim get_id As SqlCommand = New SqlCommand("select id from contents where uri='" + slug + "'", New SqlConnection(_cs))
        get_id.Connection.Open()
        Dim id As Integer = get_id.ExecuteScalar()
        Return id
    End Function
    Function Get_USER_INFO(ByVal cu As String) As ArrayList


        Dim user_info As SqlCommand = New SqlCommand("select id,username,email,password,role,post_count from user_info where username='" + cu + "'", New SqlConnection(_cs))
        user_info.Connection.Open()
        Dim info As SqlDataReader = user_info.ExecuteReader()
        Dim u_info As ArrayList = New ArrayList()
        While info.Read()
            u_info.Add(info("username"))
            u_info.Add(info("email"))
            u_info.Add(info("password"))
            u_info.Add(info("role"))
            u_info.Add(info("post_count"))
        End While
        Return u_info

    End Function
    Function Get_users(ByVal column As String) As ArrayList
        Dim result As ArrayList = New ArrayList()
        Dim q As String = "select " + column + " from user_info"
        Dim com As SqlCommand = New SqlCommand(q, New SqlConnection(_cs))
        com.Connection.Open()
        Dim data As SqlDataReader
        Try
            data = com.ExecuteReader()
            While data.Read()
                result.Add(data(column))
            End While
        Catch ex As Exception
            Return result
        End Try
        Return result
    End Function
    Function user_exist(ByVal cu As String) As Boolean
        Dim user_info As SqlCommand = New SqlCommand("select id from user_info where username='" + cu + "'", New SqlConnection(_cs))
        user_info.Connection.Open()
        If user_info.ExecuteScalar() IsNot Nothing Then
            Return True
        Else
            Return False
        End If
    End Function
    Function ADD_USER(ByVal u As String, ByVal pass As String, ByVal e As String, ByVal role As Integer) As Boolean
        Dim add_u As SqlCommand = New SqlCommand("insert into user_info values(@username, @password,@email, @role, @post_count)", New SqlConnection(_cs))
        add_u.Parameters.AddWithValue("@username", u)
        add_u.Parameters.AddWithValue("@password", pass)
        add_u.Parameters.AddWithValue("@email", e)
        add_u.Parameters.AddWithValue("@role", role)
        add_u.Parameters.AddWithValue("@post_count", 0)
        add_u.Connection.Open()
        Dim r As Boolean
        Try
            add_u.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    ''' <summary>
    ''' Gets the comments posted on specific post
    ''' </summary>
    ''' <param name="id"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function GET_COMMENTS_OF(ByVal id As Integer) As ArrayList
        Dim comments As SqlCommand = New SqlCommand("select comment,cauthor,author_email,date from comments where post_id=" + id.ToString() + " and status=1", New SqlConnection(_cs))
        Dim com As ArrayList = New ArrayList()

        comments.Connection.Open()
        Dim fet As SqlDataReader = comments.ExecuteReader()
        While fet.Read()
            com.Add(fet("comment"))
            com.Add(fet("cauthor"))
            com.Add(fet("author_email"))
            com.Add(fet("date"))
        End While
        Return com
    End Function
    Function Add_option(ByVal id As Integer, ByVal v As String) As Boolean
        Dim r As Boolean
        Dim update_set As SqlCommand = New SqlCommand("update settings set value=@v where id=@id", New SqlConnection(_cs))
        update_set.Parameters.AddWithValue("@v", v)
        update_set.Parameters.AddWithValue("@id", id)
        update_set.Connection.Open()
        Try
            update_set.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    Function Get_option(ByVal id As Integer) As String
        Dim gets As SqlCommand = New SqlCommand("select value from settings where id=@id", New SqlConnection(_cs))
        gets.Parameters.AddWithValue("@id", id)
        gets.Connection.Open()
        Try
            Return gets.ExecuteScalar().ToString()
        Catch ex As SqlException
            Return ""
        End Try
    End Function
    Function Get_Content(ByVal type As Integer, ByVal column As String) As ArrayList
        Dim s As String = column
        Dim get_posts As SqlCommand = New SqlCommand("select " + s + "  from contents where ctype=@t", New SqlConnection(_cs))
        get_posts.Parameters.AddWithValue("@c", s)
        get_posts.Parameters.AddWithValue("@t", type)
        get_posts.Connection.Open()
        Dim col As ArrayList = New ArrayList()


        Dim post_list As SqlDataReader = get_posts.ExecuteReader()


        While post_list.Read()
            col.Add(post_list(s))
        End While

        Return col
    End Function
    Function update_stat(ByVal pid As Integer) As Boolean

        Dim r As Boolean
        Dim d As String = Date.Today.ToShortDateString()
        Dim dbcon As SqlConnection = New SqlConnection(_cs)
        dbcon.Open()
        Dim get_stat As SqlCommand = New SqlCommand("select views from stats where date=@d", dbcon)
        get_stat.Parameters.AddWithValue("@d", d)

        If get_stat.ExecuteScalar() Is Nothing Then
            If add_stats() = False Then
                Return False
            End If
        End If
        Dim update As SqlCommand = New SqlCommand("update stats set views=@nv where date=@d", dbcon)
        Dim get_post_stat As SqlCommand = New SqlCommand("select views from contents where id=@i", dbcon)
        Dim update_post As SqlCommand = New SqlCommand("update contents set views=@v where id=@i", dbcon)
        Dim cv As Integer = get_stat.ExecuteScalar()
        update.Parameters.AddWithValue("@nv", cv + 1)
        update.Parameters.AddWithValue("@d", d)
        get_post_stat.Parameters.AddWithValue("@i", pid)
        update_post.Parameters.AddWithValue("@v", get_post_stat.ExecuteScalar() + 1)
        update_post.Parameters.AddWithValue("@i", pid)
        Try

            update.ExecuteNonQuery()
            update_post.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    Function add_stats() As Boolean
        Dim r As Boolean
        Dim dbcon As SqlConnection = New SqlConnection(_cs)
        dbcon.Open()
        Dim add_entry As SqlCommand = New SqlCommand("insert into stats values(@d,0);", dbcon)
        add_entry.Parameters.AddWithValue("@d", Date.Today.ToShortDateString())
        Try
            add_entry.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    Function init() As Boolean
        Dim r As Boolean
        Dim dbc As SqlConnection = New SqlConnection(_cs)
        Try
            dbc.Open()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    ''' <summary>
    ''' Searches the enterd keyword and returns the matches as arraylist of titles
    ''' </summary>
    ''' <param name="type"></param>
    ''' <param name="s"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function Search(ByVal type As Integer, ByVal s As String) As ArrayList

        Dim GetCon As SqlCommand = New SqlCommand("select title from contents where ctype=@t", New SqlConnection(_cs))
        GetCon.Connection.Open()
        GetCon.Parameters.AddWithValue("@t", type)
        Dim content_list As SqlDataReader = GetCon.ExecuteReader()
        Dim titles As ArrayList = New ArrayList()
        Dim result As ArrayList = New ArrayList()
        While content_list.Read()
            titles.Add(content_list("title"))
        End While
        For i As Integer = 0 To titles.Count - 1
            If Not c.Search_substring(titles(i).ToString().ToLower(), s) = -1 Then
                result.Add(titles(i).ToString())
            End If
        Next
        Return result
    End Function
    Function GET_BY_ID(ByVal id As Integer, ByVal col As String, ByVal table As String) As String
        Dim t As String = table
        Dim i As Integer = id
        Dim s As String = "select " + col + " from " + t + " where id=@i"
        Dim get_ As SqlCommand = New SqlCommand(s, New SqlConnection(_cs))

        get_.Parameters.AddWithValue("@i", i)
        get_.Connection.Open()
        Try
            If get_.ExecuteScalar() IsNot Nothing Then
                Return get_.ExecuteScalar().ToString()
            Else
                Return ""
            End If

        Catch ex As SqlException
            Return ""
        End Try


    End Function
    Function Put_data(ByVal table As String, ByVal values As ArrayList) As Boolean
        Dim r As Boolean
        Dim com As String = "insert into " + table + " values("
        For i As Integer = 0 To values.Count - 1
            com += "@a" + i.ToString()
            If Not i = values.Count - 1 Then
                com += ","
            End If
        Next
        com += ")"
        Dim p As String
        Dim put_com As SqlCommand = New SqlCommand(com, New SqlConnection(_cs))

        For i As Integer = 0 To values.Count - 1
            p = "@a" + i.ToString()
            put_com.Parameters.AddWithValue(p, values(i))
        Next
        Try
            put_com.Connection.Open()
            put_com.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    ''' <summary>
    ''' Gets collection of entries present inspecified column
    ''' </summary>
    ''' <param name="col"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function Get_categories(ByVal col As String) As ArrayList

        Dim get_cat As SqlCommand = New SqlCommand("select " + col + "  from categories", New SqlConnection(_cs))
        get_cat.Connection.Open()
        Dim cols As ArrayList = New ArrayList()

        Try
            Dim post_list As SqlDataReader = get_cat.ExecuteReader()
            While post_list.Read()
                cols.Add(post_list(col))
            End While
        Catch ex As SqlException
            Return cols
        End Try



       

        Return cols

    End Function
    Function GET_ID(ByVal table As String, ByVal column As String, ByVal unique As String) As Integer
        Dim id As Integer = 0
        Dim s As String = "select id from " + table + " where " + column + "=@c"
        Dim ret_id As SqlCommand = New SqlCommand(s, New SqlConnection(_cs))
        ret_id.Parameters.AddWithValue("@c", unique)
        Try
            ret_id.Connection.Open()
            id = ret_id.ExecuteScalar()
        Catch ex As Exception

        End Try
        Return id

    End Function
    Function _GET(ByVal table As String, ByVal id As Integer, ByVal column As String) As String
        Dim r As String
        Dim g As SqlCommand = New SqlCommand("select " + column + " from " + table + " where id=@i", New SqlConnection(_cs))
        g.Parameters.AddWithValue("@i", id)
        g.Connection.Open()
        Try
            r = g.ExecuteScalar()

        Catch ex As SqlException
            r = ""
        End Try
        Return r
    End Function
    Function Update_user(ByVal username As String, ByVal email As String, ByVal password As String, ByVal role As String) As Boolean
        Dim r As Boolean
        Dim com As String = "update user_info set password='" + password + "',email='" + email + "',role='" + role + "' where username='" + username + "'"
        Dim u_u As SqlCommand = New SqlCommand(com, New SqlConnection(_cs))
        u_u.Connection.Open()
        Try
            u_u.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    Function update_avatar(ByVal link As String, ByVal username As String) As Boolean
        Dim r As Boolean
        Dim com As SqlCommand = New SqlCommand("update user_info set avatar='" + link + "' where username='" + username + "'", New SqlConnection(_cs))
        Try
            com.Connection.Open()
            com.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    Function Update_page(ByVal id As Integer, ByVal title As String, ByVal uri As String, ByVal text As String, ByVal seo_title As String, ByVal seo_meta As String) As Boolean
        Dim r As Boolean
        Dim com As String = "update contents set title='" + title + "',uri='" + uri + "',ctext='" + Text + "',seo_title='" + seo_title + "',seo_meta='" + seo_meta + "' where id=" + id.ToString()
        Dim up As SqlCommand = New SqlCommand(com, New SqlConnection(_cs))
        up.Connection.Open()
        Try
            up.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    Function update_post(ByVal id As Integer, ByVal title As String, ByVal uri As String, ByVal category_id As Integer, ByVal text As String, ByVal seo_title As String, ByVal seo_meta As String) As Boolean
        Dim r As Boolean
        Dim com As String = "update contents set title='" + title + "',uri='" + uri + "',ctext='" + text + "',seo_title='" + seo_title + "',seo_meta='" + seo_meta + "',cat_id=@c where id=" + id.ToString()

        Dim up As SqlCommand = New SqlCommand(com, New SqlConnection(_cs))
        up.Parameters.AddWithValue("@c", category_id)
        up.Connection.Open()
        Try
            up.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    Function update_category(ByVal id As Integer, ByVal title As String, ByVal description As String) As Boolean
        Dim r As Boolean
        Dim com As String = "update categories set title='" + title + "',description='" + description + "' where id=" + id.ToString()

        Dim up As SqlCommand = New SqlCommand(com, New SqlConnection(_cs))

        up.Connection.Open()
        Try
            up.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    ''' <summary>
    ''' Gets collection of all entries specified column from comments table
    ''' </summary>
    ''' <param name="column"></param>
    ''' <returns>arraylist</returns>
    ''' <remarks></remarks>
    Function Get_comments(ByVal column As String) As ArrayList

        Dim result As ArrayList = New ArrayList()
        Dim com As String = "select " + column + " from comments"
        Dim q As SqlCommand = New SqlCommand(com, New SqlConnection(_cs))
        q.Connection.Open()

        Try
            Dim list As SqlDataReader = q.ExecuteReader()
            While list.Read()
                result.Add(list(column))
            End While
        Catch ex As SqlException
            Return result
        End Try
        Return result
    End Function
    Function Get_notifications(ByVal type As Integer, ByVal column As String) As ArrayList
        Dim get_noti As SqlCommand = New SqlCommand("select " + column + "  from notifications where type=@t", New SqlConnection(_cs))

        get_noti.Parameters.AddWithValue("@t", type)
        get_noti.Connection.Open()
        Dim col As ArrayList = New ArrayList()


        Dim noti_list As SqlDataReader = get_noti.ExecuteReader()


        While noti_list.Read()
            col.Add(noti_list(column))
        End While

        Return col
    End Function
    Function update_status(ByVal table As String, ByVal id As Integer, ByVal status As Integer) As Boolean
        Dim r As Boolean
        Dim q As String = "update " + table + " set status=@s where id=@i"
        Dim com As SqlCommand = New SqlCommand(q, New SqlConnection(_cs))
        com.Parameters.AddWithValue("@s", status)
        com.Parameters.AddWithValue("@i", id)
        Try
            com.Connection.Open()
            com.ExecuteNonQuery()
            r = True
        Catch ex As Exception
            r = False
        End Try
        Return r
    End Function
    Function _delete(ByVal table As String, ByVal id As Integer) As Boolean
        Dim r As Boolean
        Dim q As String = "delete from " + table + " where id=@i"
        Dim com As SqlCommand = New SqlCommand(q, New SqlConnection(_cs))
        com.Parameters.AddWithValue("@i", id)
        Try
            com.Connection.Open()
            com.ExecuteNonQuery()
            r = True

        Catch ex As Exception
            r = False
        End Try
        Return r
    End Function
    Function update_menu(ByVal name As String, ByVal titles As String, ByVal urls As String) As Boolean
        Dim r As Boolean
        Dim comm As SqlCommand = New SqlCommand("update nav set titles=@t,url=@u where name=@n", New SqlConnection(_cs))
        comm.Parameters.AddWithValue("@t", titles)
        comm.Parameters.AddWithValue("@u", urls)
        comm.Parameters.AddWithValue("@n", name)
        comm.Connection.Open()
        Try
            comm.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r
    End Function
    Function create_table(ByVal name As String, ByVal columns As ArrayList, ByVal datatypes As ArrayList, ByVal keys As ArrayList) As Boolean
        Dim r As Boolean
        Dim q As String = "create table " + name + "("
        For i As Integer = 0 To columns.Count - 1
            q += columns(i).ToString() + " " + datatypes(i).ToString() + " " + keys(i).ToString()
            If i < columns.Count - 1 Then
                q += ","
            End If
        Next
        q += ")"
        Dim com As SqlCommand = New SqlCommand(q, New SqlConnection(_cs))
        Try
            com.Connection.Open()
            com.ExecuteNonQuery()
            r = True
        Catch ex As Exception
            r = False
        End Try
        Return r
    End Function
    Function _update(ByVal id As Integer, ByVal table As String, ByVal column_name As String, ByVal value As ArrayList) As Boolean
        Dim r As Boolean
        ' Dim q As String = "update " + table + " set " + column_name + "=@n where id=" + id.ToString()
        Dim comm As SqlCommand = New SqlCommand("update " + table + " set " + column_name + "=@n where id=" + id.ToString(), New SqlConnection(_cs))
        comm.Parameters.AddWithValue("@n", value(0))
        Try
            comm.Connection.Open()
            comm.ExecuteNonQuery()
            r = True
        Catch ex As Exception
            r = False
        End Try
        Return r
    End Function
    Function register_template(ByVal name As String) As Boolean
        Dim r As Boolean
        Dim comm As SqlCommand = New SqlCommand("insert into templates values('" + name + "','true')", New SqlConnection(_cs))
        Try
            comm.Connection.Open()
            comm.ExecuteNonQuery()
            r = True
        Catch ex As Exception
            r = False
        End Try
        Return r
    End Function
    ''' <summary>
    ''' Gets the value from specified column by refering unique value of specified unique value column
    ''' </summary>
    ''' <param name="table"></param>
    ''' <param name="column"></param>
    ''' <param name="unique"></param>
    ''' <param name="unique_value_column"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function GET_WITHOUT_ID(ByVal table As String, ByVal column As String, ByVal unique As String, ByVal unique_value_column As String) As String
        Dim r As String
        Dim g As SqlCommand = New SqlCommand("select " + column + " from " + table + " where " + unique_value_column + "=@i", New SqlConnection(_cs))
        g.Parameters.AddWithValue("@i", unique)
        g.Connection.Open()
        Try
            r = g.ExecuteScalar()

        Catch ex As SqlException
            r = ""
        End Try
        Return r
    End Function
    Function Get_max(ByVal table As String, ByVal column As Integer) As Integer
        Dim m As Integer = 0
        Dim com As SqlCommand = New SqlCommand("select max(" + column + ") from table " + table, New SqlConnection(_cs))
        Try
            m = com.ExecuteScalar()
        Catch ex As SqlException
            m = 0
        End Try
        Return m
    End Function
    Function GET_V2(ByVal table As String, ByVal column As String, ByVal unique_val_column As String, ByVal value As ArrayList) As String
        Dim r As String = ""
        Dim g As SqlCommand = New SqlCommand("select " + column + " from " + table + " where " + unique_val_column + "=@i", New SqlConnection(_cs))
        g.Parameters.AddWithValue("@i", value(0))
        g.Connection.Open()
        Try
            r = g.ExecuteScalar()

        Catch ex As SqlException
            r = ""
        End Try
        Return r
    End Function
End Class

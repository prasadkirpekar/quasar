﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Public Class Notifications
    Dim _cs As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True"
    Dim con As SqlConnection = New SqlConnection(_cs)

    Function Add_notification(ByVal type As Integer, ByVal text As String, ByVal status As Integer, ByVal author_id As Integer) As Boolean
        Dim r As Boolean
        Dim add_noti As SqlCommand = New SqlCommand("insert into notifications values(@ty,@te,@st,@ai)", con)
        add_noti.Parameters.AddWithValue("@ty", type)
        add_noti.Parameters.AddWithValue("@te", text)
        add_noti.Parameters.AddWithValue("@st", status)
        add_noti.Parameters.AddWithValue("@ai", author_id)
        Try
            con.Open()
            add_noti.ExecuteNonQuery()
            r = True
        Catch ex As SqlException
            r = False
        End Try
        Return r

    End Function
    Function Get_notification_count(ByVal author_id As Integer) As Integer
        Dim r As Integer
        Dim get_count As SqlCommand = New SqlCommand("select text from notifications where type=1 and status=1 and author_id=@i", con)
        get_count.Parameters.AddWithValue("@i", author_id)
        con.Open()
        Dim list As SqlDataReader = get_count.ExecuteReader()

        Try
            While list.Read()
                r += 1
            End While

        Catch ex As SqlException
            r = -1
        End Try
        Return r
    End Function
End Class

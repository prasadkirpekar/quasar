﻿Imports Microsoft.VisualBasic
Imports System.Security.Cryptography
Imports RandomKeyGenerator
Imports System.Data.SqlClient
Imports System.Web.UI.Page
Public Class security
    Dim _cs As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True"

    Function get_user_role(ByVal un As String) As Integer
        Dim dbcon As SqlConnection = New SqlConnection(_cs)
        dbcon.Open()
        Dim get_role As SqlCommand = New SqlCommand("select role from user_info where username='" + un + "'", dbcon)
        Dim r As Integer = get_role.ExecuteScalar()
        dbcon.Close()
        Return r
    End Function
    
    Public Function random_string() As String
        Dim KeyGen As RandomKeyGenerator
        Dim RandomKey As String
        KeyGen = New RandomKeyGenerator
        KeyGen.KeyLetters = "abcdefghijklmnopqrstuvwxyz"
        KeyGen.KeyNumbers = "0123456789"
        KeyGen.KeyChars = 12
        RandomKey = KeyGen.Generate()

        Return RandomKey
    End Function
    Function IS_LOGGED_IN() As Boolean
        Return True
    End Function
End Class
